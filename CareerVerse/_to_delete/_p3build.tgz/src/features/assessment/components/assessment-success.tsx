"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { CheckCircleIcon, ArrowRightIcon } from "@/components/ui/icon";
import { ROUTES } from "@/config/routes";

export function AssessmentSuccess({ onGoDashboard }: { onGoDashboard: () => void }) {
  return (
    <div className="mx-auto max-w-xl py-6 text-center">
      <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-success/10 text-success">
        <CheckCircleIcon size={34} />
      </div>
      <h1 className="mt-5 text-2xl font-semibold tracking-tight">Assessment complete</h1>
      <p className="mx-auto mt-2 max-w-md text-sm text-muted">
        Nicely done. We&apos;ve saved your responses and built your career profile. It now powers your
        dashboard — and it&apos;s the foundation for the personalized recommendations, roadmaps, and
        interview practice coming next.
      </p>

      <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
        <Button size="lg" onClick={onGoDashboard}>
          Go to dashboard
          <ArrowRightIcon size={18} />
        </Button>
        <Link
          href={ROUTES.profile}
          className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-foreground/15 px-6 text-base font-medium transition-colors hover:bg-foreground/5"
        >
          View profile
        </Link>
      </div>
    </div>
  );
}
