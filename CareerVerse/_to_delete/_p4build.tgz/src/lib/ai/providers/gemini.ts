import type { ZodType } from "zod";
import { serverEnv } from "@/lib/env.server";
import {
  AIError,
  type AIProvider,
  type GenerateObjectOptions,
  type GenerateTextOptions,
  type ObjectResult,
  type TextResult,
  type TokenUsage,
} from "../types";

const ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models";

interface GeminiResponse {
  candidates?: Array<{
    content?: { parts?: Array<{ text?: string }> };
    finishReason?: string;
  }>;
  usageMetadata?: {
    promptTokenCount?: number;
    candidatesTokenCount?: number;
    totalTokenCount?: number;
  };
  promptFeedback?: { blockReason?: string };
}

function stripCodeFences(text: string): string {
  const trimmed = text.trim();
  if (trimmed.startsWith("```")) {
    return trimmed
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/\s*```$/, "")
      .trim();
  }
  return trimmed;
}

/**
 * Google Gemini adapter — the default provider. Implemented against the REST
 * API with the runtime's built-in fetch so we add no dependency; the adapter is
 * the only place that knows Gemini's wire format.
 */
export function createGeminiProvider(): AIProvider {
  const apiKey = serverEnv.GEMINI_API_KEY;
  const model = serverEnv.GEMINI_MODEL;

  if (!apiKey) {
    throw new AIError(
      "AI is not configured. Set GEMINI_API_KEY in your environment to enable AI features.",
      "not_configured",
    );
  }

  function buildBody(options: GenerateObjectOptions, asJson: boolean): Record<string, unknown> {
    const generationConfig: Record<string, unknown> = {
      temperature: options.temperature ?? 0.6,
      maxOutputTokens: options.maxOutputTokens ?? 4096,
    };
    if (asJson) {
      generationConfig.responseMimeType = "application/json";
      if (options.responseSchema) generationConfig.responseSchema = options.responseSchema;
    }

    const body: Record<string, unknown> = {
      contents: [{ role: "user", parts: [{ text: options.prompt }] }],
      generationConfig,
    };
    if (options.system) {
      body.systemInstruction = { parts: [{ text: options.system }] };
    }
    return body;
  }

  async function call(body: Record<string, unknown>): Promise<{ text: string; usage: TokenUsage }> {
    let response: Response;
    try {
      response = await fetch(`${ENDPOINT}/${model}:generateContent?key=${apiKey}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
    } catch (error) {
      throw new AIError(
        "Could not reach the AI provider.",
        "provider_error",
        error instanceof Error ? error.message : undefined,
      );
    }

    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      throw new AIError(`AI request failed (${response.status}).`, "provider_error", detail);
    }

    const json = (await response.json()) as GeminiResponse;

    if (json.promptFeedback?.blockReason) {
      throw new AIError("The request was blocked by the AI provider.", "provider_error", json.promptFeedback.blockReason);
    }

    const parts = json.candidates?.[0]?.content?.parts ?? [];
    const text = parts.map((part) => part.text ?? "").join("");
    if (!text.trim()) {
      throw new AIError("The AI returned an empty response.", "empty_response", json.candidates?.[0]?.finishReason);
    }

    const meta = json.usageMetadata ?? {};
    const usage: TokenUsage = {
      inputTokens: meta.promptTokenCount ?? 0,
      outputTokens: meta.candidatesTokenCount ?? 0,
      totalTokens: meta.totalTokenCount ?? 0,
    };

    return { text, usage };
  }

  return {
    name: "gemini",
    model,
    capabilities: { streaming: false, embeddings: false, structuredOutput: true },

    async generateText(options: GenerateTextOptions): Promise<TextResult> {
      const { text, usage } = await call(buildBody(options, false));
      return { text, usage };
    },

    async generateObject<T>(
      schema: ZodType<T>,
      options: GenerateObjectOptions,
    ): Promise<ObjectResult<T>> {
      const { text, usage } = await call(buildBody(options, true));

      let parsed: unknown;
      try {
        parsed = JSON.parse(stripCodeFences(text));
      } catch {
        throw new AIError("The AI returned invalid JSON.", "invalid_json");
      }

      const result = schema.safeParse(parsed);
      if (!result.success) {
        throw new AIError(
          "The AI response did not match the expected format.",
          "schema_mismatch",
          result.error.message,
        );
      }

      return { data: result.data, usage };
    },
  };
}
