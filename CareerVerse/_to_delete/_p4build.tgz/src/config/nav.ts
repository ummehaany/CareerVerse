import type { ComponentType } from "react";
import type { IconProps } from "@/components/ui/icon";
import {
  HomeIcon,
  CompassIcon,
  TargetIcon,
  RouteIcon,
  FileTextIcon,
  MicIcon,
  SparklesIcon,
  UserIcon,
  SettingsIcon,
} from "@/components/ui/icon";
import type { UserRole } from "@/types/user";
import { ROUTES } from "./routes";

/*
 * Data-driven navigation (architecture §6). Links, icons, grouping and role
 * gating are declared once here and consumed by every nav surface (sidebar,
 * mobile drawer, and — later — the command palette) so they never drift.
 */
export interface NavItem {
  key: string;
  label: string;
  href: string;
  icon: ComponentType<IconProps>;
  /** When set, the item renders only for users holding one of these roles. */
  roles?: UserRole[];
}

export interface NavGroup {
  key: string;
  /** Optional section heading shown above the group. */
  label?: string;
  items: NavItem[];
}

export const navGroups: NavGroup[] = [
  {
    key: "main",
    items: [
      { key: "dashboard", label: "Dashboard", href: ROUTES.dashboard, icon: HomeIcon },
      { key: "assessment", label: "Career Assessment", href: ROUTES.assessment, icon: CompassIcon },
      { key: "recommendations", label: "Career Matches", href: ROUTES.recommendations, icon: TargetIcon },
      { key: "roadmap", label: "Learning Roadmap", href: ROUTES.roadmap, icon: RouteIcon },
      { key: "resume", label: "Resume Builder", href: ROUTES.resume, icon: FileTextIcon },
      { key: "interviews", label: "Mock Interviews", href: ROUTES.interviews, icon: MicIcon },
      { key: "mentor", label: "AI Mentor", href: ROUTES.mentor, icon: SparklesIcon },
    ],
  },
  {
    key: "account",
    label: "Account",
    items: [
      { key: "profile", label: "Profile", href: ROUTES.profile, icon: UserIcon },
      { key: "settings", label: "Settings", href: ROUTES.settings, icon: SettingsIcon },
    ],
  },
];

/** Drop items the given role may not see. Groups left empty are removed. */
export function navForRole(role: UserRole | undefined): NavGroup[] {
  return navGroups
    .map((group) => ({
      ...group,
      items: group.items.filter((item) => !item.roles || (role && item.roles.includes(role))),
    }))
    .filter((group) => group.items.length > 0);
}
