import type { Metadata } from "next";
import { getCurrentUser } from "@/lib/firebase/auth";

export const metadata: Metadata = { title: "Dashboard" };

// Placeholder landing for authenticated users. The functional dashboard is
// built in Phase 3 per the architecture roadmap.
export default async function DashboardPage() {
  const user = await getCurrentUser();
  const name = user?.displayName ?? user?.email ?? "there";

  return (
    <div className="space-y-2">
      <h1 className="text-2xl font-semibold tracking-tight">Welcome, {name}.</h1>
      <p className="text-foreground/60">
        You&apos;re signed in. Your personalized dashboard will be built in Phase 3.
      </p>
    </div>
  );
}
