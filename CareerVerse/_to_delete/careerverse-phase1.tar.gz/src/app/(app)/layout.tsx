import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/firebase/auth";
import { ROUTES } from "@/config/routes";
import { SignOutButton } from "@/features/auth/components/sign-out-button";

// Authoritative auth gate for the application. The full app shell (sidebar,
// nav, command palette) is built in Phase 3; this is a minimal authenticated
// frame so protected routing and sign-out are functional in Phase 1.
export default async function AppLayout({ children }: { children: ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect(ROUTES.login);

  return (
    <div className="min-h-screen">
      <header className="flex items-center justify-between border-b border-foreground/10 px-4 py-3 sm:px-6">
        <span className="font-bold tracking-tight">CareerVerse</span>
        <div className="flex items-center gap-3">
          <span className="hidden text-sm text-foreground/60 sm:inline">
            {user.displayName ?? user.email}
          </span>
          <SignOutButton />
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl px-4 py-8 sm:px-6">{children}</main>
    </div>
  );
}
