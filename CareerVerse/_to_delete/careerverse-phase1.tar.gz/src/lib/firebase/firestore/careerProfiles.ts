import { adminDb, FieldValue } from "@/lib/firebase/admin";
import type { CareerProfile } from "@/types";

const COLLECTION = "careerProfiles";

export async function getCareerProfile(uid: string): Promise<CareerProfile | null> {
  const snap = await adminDb.collection(COLLECTION).doc(uid).get();
  return snap.exists ? (snap.data() as CareerProfile) : null;
}

/**
 * Idempotently create an empty `careerProfiles/{uid}` document. The profile is
 * populated later by the onboarding assessment (Phase 5).
 */
export async function ensureCareerProfile(uid: string): Promise<void> {
  const ref = adminDb.collection(COLLECTION).doc(uid);
  const snap = await ref.get();
  if (snap.exists) return;

  await ref.set({
    uid,
    education: [],
    experience: [],
    currentRole: null,
    skills: [],
    interests: [],
    goals: [],
    targetRoles: [],
    strengths: [],
    aiSummary: null,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  });
}
