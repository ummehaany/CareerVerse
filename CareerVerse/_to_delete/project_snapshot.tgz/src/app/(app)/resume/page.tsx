import type { Metadata } from "next";
import { ComingSoon } from "@/components/shared/coming-soon";
import { FileTextIcon } from "@/components/ui/icon";

export const metadata: Metadata = { title: "Resume Builder" };

export default function ResumePage() {
  return (
    <ComingSoon
      title="Resume Builder"
      description="Draft and refine a standout resume with inline AI suggestions, versioning, and export."
      icon={FileTextIcon}
      bullets={[
        "Section-based editor with inline AI suggestions",
        "Version history so you can compare and revert",
        "One-click PDF export",
      ]}
    />
  );
}
