import type { Metadata } from "next";
import { ComingSoon } from "@/components/shared/coming-soon";
import { MicIcon } from "@/components/ui/icon";

export const metadata: Metadata = { title: "Mock Interviews" };

export default function InterviewsPage() {
  return (
    <ComingSoon
      title="Mock Interviews"
      description="Practice role-specific interviews with streamed questions and scored, actionable feedback."
      icon={MicIcon}
      bullets={[
        "Role-specific question sets tailored to your target",
        "Streamed, conversational interview sessions",
        "Scored feedback with concrete areas to improve",
      ]}
    />
  );
}
