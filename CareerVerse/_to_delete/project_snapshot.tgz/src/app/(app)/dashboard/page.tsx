import type { Metadata } from "next";
import { getCurrentUser } from "@/lib/firebase/auth";
import { getCareerProfile } from "@/lib/firebase/firestore/careerProfiles";
import type { SessionUser } from "@/types/session";
import { WelcomeBanner } from "@/features/dashboard/components/welcome-banner";
import { ProfileSnapshot } from "@/features/dashboard/components/profile-snapshot";
import { QuickActions } from "@/features/dashboard/components/quick-actions";
import { StatCard } from "@/features/dashboard/components/stat-card";
import { FeatureCard } from "@/features/dashboard/components/feature-card";
import {
  FEATURE_SECTIONS,
  OVERVIEW_STATS,
  computeProfileCompleteness,
} from "@/features/dashboard/config";

export const metadata: Metadata = { title: "Dashboard" };

export default async function DashboardPage() {
  const user = await getCurrentUser();
  const profile = user ? await getCareerProfile(user.uid) : null;

  const completeness = computeProfileCompleteness(profile);
  const onboardingComplete = user?.onboardingComplete ?? false;
  const firstName =
    user?.displayName?.split(" ")[0] ?? user?.email?.split("@")[0] ?? "there";

  const sessionUser: SessionUser = {
    uid: user?.uid ?? "",
    displayName: user?.displayName ?? null,
    email: user?.email ?? null,
    photoURL: user?.photoURL ?? null,
    role: user?.role ?? "student",
    plan: user?.plan ?? "free",
  };

  // Inject the one live reading; the rest stay as placeholder slots.
  const stats = OVERVIEW_STATS.map((stat) =>
    stat.key === "profile"
      ? { ...stat, value: `${completeness}%`, progress: completeness }
      : stat,
  );

  return (
    <div className="space-y-8">
      <WelcomeBanner name={firstName} onboardingComplete={onboardingComplete} />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <section className="space-y-3">
            <h2 className="text-xs font-semibold uppercase tracking-wide text-subtle">
              Quick actions
            </h2>
            <QuickActions />
          </section>

          <section className="space-y-3">
            <h2 className="text-xs font-semibold uppercase tracking-wide text-subtle">
              Your progress
            </h2>
            <div className="grid gap-4 sm:grid-cols-2">
              {stats.map((stat) => (
                <StatCard key={stat.key} stat={stat} />
              ))}
            </div>
          </section>
        </div>

        <section className="space-y-3">
          <h2 className="text-xs font-semibold uppercase tracking-wide text-subtle">Profile</h2>
          <ProfileSnapshot
            user={sessionUser}
            completeness={completeness}
            onboardingComplete={onboardingComplete}
          />
        </section>
      </div>

      <section className="space-y-4">
        <div className="flex items-end justify-between">
          <h2 className="text-lg font-semibold tracking-tight">Explore CareerVerse</h2>
          <p className="hidden text-sm text-muted sm:block">
            Five ways to move your career forward
          </p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {FEATURE_SECTIONS.map((feature) => (
            <FeatureCard key={feature.key} feature={feature} />
          ))}
        </div>
      </section>
    </div>
  );
}
