import type { Metadata } from "next";
import { ComingSoon } from "@/components/shared/coming-soon";
import { RouteIcon } from "@/components/ui/icon";

export const metadata: Metadata = { title: "Learning Roadmap" };

export default function RoadmapPage() {
  return (
    <ComingSoon
      title="Learning Roadmap"
      description="A personalized, milestone-based plan toward your target role that you track over time."
      icon={RouteIcon}
      bullets={[
        "AI-generated milestones tailored to your profile and target role",
        "Curated resources attached to each milestone",
        "Progress tracking that surfaces on your dashboard",
      ]}
    />
  );
}
