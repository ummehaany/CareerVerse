import type { ComponentType } from "react";
import type { IconProps } from "@/components/ui/icon";
import {
  CompassIcon,
  RouteIcon,
  FileTextIcon,
  MicIcon,
  SparklesIcon,
  TargetIcon,
  TrendingUpIcon,
  ClockIcon,
} from "@/components/ui/icon";
import { ROUTES } from "@/config/routes";
import type { CareerProfile } from "@/types/career-profile";

/*
 * Dashboard is composed from data-driven slots. Each later feature phase fills
 * its slot with live data; for now these describe the placeholder surfaces so
 * the layout is complete and consistent.
 */

export interface FeatureSection {
  key: string;
  title: string;
  description: string;
  href: string;
  cta: string;
  icon: ComponentType<IconProps>;
  /** CSS custom property name for the section's accent color. */
  accentVar: string;
  /** Placeholder status label until the feature is wired up. */
  status: string;
}

export const FEATURE_SECTIONS: FeatureSection[] = [
  {
    key: "assessment",
    title: "Career Assessment",
    description:
      "Answer a short questionnaire and get an AI-generated career profile with strengths and matched roles.",
    href: ROUTES.assessment,
    cta: "Start assessment",
    icon: CompassIcon,
    accentVar: "--accent-assessment",
    status: "Not started",
  },
  {
    key: "roadmap",
    title: "Learning Roadmap",
    description:
      "A personalized, milestone-based plan toward your target role — tracked as you learn.",
    href: ROUTES.roadmap,
    cta: "Build roadmap",
    icon: RouteIcon,
    accentVar: "--accent-roadmap",
    status: "Not started",
  },
  {
    key: "resume",
    title: "Resume Builder",
    description:
      "Draft and refine a standout resume with inline AI suggestions, versions, and PDF export.",
    href: ROUTES.resume,
    cta: "Create resume",
    icon: FileTextIcon,
    accentVar: "--accent-resume",
    status: "Not started",
  },
  {
    key: "interviews",
    title: "Mock Interviews",
    description:
      "Practice role-specific interviews with streamed questions and scored, actionable feedback.",
    href: ROUTES.interviews,
    cta: "Start practicing",
    icon: MicIcon,
    accentVar: "--accent-interview",
    status: "Not started",
  },
  {
    key: "mentor",
    title: "AI Mentor",
    description:
      "Chat with a mentor that knows your profile and progress, available whenever you need guidance.",
    href: ROUTES.mentor,
    cta: "Ask your mentor",
    icon: SparklesIcon,
    accentVar: "--accent-mentor",
    status: "Not started",
  },
];

export interface QuickAction {
  key: string;
  label: string;
  href: string;
  icon: ComponentType<IconProps>;
}

export const QUICK_ACTIONS: QuickAction[] = [
  { key: "assessment", label: "Take assessment", href: ROUTES.assessment, icon: CompassIcon },
  { key: "roadmap", label: "New roadmap", href: ROUTES.roadmap, icon: RouteIcon },
  { key: "resume", label: "New resume", href: ROUTES.resume, icon: FileTextIcon },
  { key: "interview", label: "Mock interview", href: ROUTES.interviews, icon: MicIcon },
  { key: "mentor", label: "Ask mentor", href: ROUTES.mentor, icon: SparklesIcon },
];

export interface OverviewStat {
  key: string;
  label: string;
  value: string;
  hint: string;
  /** 0–100 to show a meter, or null for a bare figure. */
  progress: number | null;
  icon: ComponentType<IconProps>;
  accentVar: string;
}

// Placeholder metrics — the dashboard overrides `profile` with a live reading
// and later phases replace the rest with real progress.
export const OVERVIEW_STATS: OverviewStat[] = [
  {
    key: "profile",
    label: "Profile completeness",
    value: "0%",
    hint: "Finish onboarding to unlock matches",
    progress: 0,
    icon: TargetIcon,
    accentVar: "--accent-assessment",
  },
  {
    key: "roadmap",
    label: "Roadmap progress",
    value: "0%",
    hint: "No active roadmap yet",
    progress: 0,
    icon: TrendingUpIcon,
    accentVar: "--accent-roadmap",
  },
  {
    key: "interviews",
    label: "Interviews practiced",
    value: "0",
    hint: "Your best score will show here",
    progress: null,
    icon: MicIcon,
    accentVar: "--accent-interview",
  },
  {
    key: "activity",
    label: "Activity",
    value: "New",
    hint: "Come back daily to build a streak",
    progress: null,
    icon: ClockIcon,
    accentVar: "--accent-mentor",
  },
];

/** Rough profile-completeness score (0–100) from the filled profile fields. */
export function computeProfileCompleteness(profile: CareerProfile | null): number {
  if (!profile) return 0;
  const checks = [
    profile.education.length > 0,
    profile.experience.length > 0,
    Boolean(profile.currentRole),
    profile.skills.length > 0,
    profile.interests.length > 0,
    profile.goals.length > 0,
    profile.targetRoles.length > 0,
    profile.strengths.length > 0,
    Boolean(profile.aiSummary),
  ];
  const done = checks.filter(Boolean).length;
  return Math.round((done / checks.length) * 100);
}
