import type { Metadata } from "next";
import { ComingSoon } from "@/components/shared/coming-soon";
import { CompassIcon } from "@/components/ui/icon";

export const metadata: Metadata = { title: "Career Assessment" };

export default function AssessmentPage() {
  return (
    <ComingSoon
      title="Career Assessment"
      description="A guided questionnaire that turns your interests, skills, and goals into an AI-generated career profile."
      icon={CompassIcon}
      bullets={[
        "Step-by-step questionnaire across interests, skills, and goals",
        "AI-generated career profile with strengths and matched roles",
        "Feeds every other feature — roadmaps, matches, and mentorship",
      ]}
    />
  );
}
