/** Centralized route paths. Import these instead of hardcoding strings. */
export const ROUTES = {
  home: "/",
  login: "/login",
  signup: "/signup",
  forgotPassword: "/forgot-password",
  verifyEmail: "/verify-email",

  // Authenticated app
  dashboard: "/dashboard",
  assessment: "/assessment",
  roadmap: "/roadmap",
  resume: "/resume",
  interviews: "/interviews",
  mentor: "/mentor",
  profile: "/profile",
  settings: "/settings",
} as const;

export type RouteKey = keyof typeof ROUTES;
