export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-4 p-8 text-center">
      <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">CareerVerse</h1>
      <p className="max-w-md text-base text-foreground/70">
        Project scaffold is ready. Start building your features here.
      </p>
    </main>
  );
}
