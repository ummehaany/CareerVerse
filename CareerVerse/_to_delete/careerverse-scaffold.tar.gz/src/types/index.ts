/**
 * Shared application types.
 * Export cross-cutting TypeScript types and interfaces from here.
 */

export {};
